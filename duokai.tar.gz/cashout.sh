#!/usr/bin/env bash

function getPeers() {
  curl -s "http://localhost:$DEBUG_API/chequebook/cheque" | jq -r '.lastcheques | .[].peer'
}

function getCumulativePayout() {
  local peer=$1
  local cumulativePayout=$(curl -s "http://localhost:$DEBUG_API/chequebook/cheque/$peer" | jq '.lastreceived.payout')
  if [ $cumulativePayout == null ]
  then
    echo 0
  else
    echo $cumulativePayout
  fi
}

function getLastCashedPayout() {
  local peer=$1
  local cashout=$(curl -s "http://localhost:$DEBUG_API/chequebook/cashout/$peer" | jq '.cumulativePayout')
  if [ $cashout == null ]
  then
    echo 0
  else
    echo $cashout
  fi
}

function getUncashedAmount() {
  local peer=$1
  local cumulativePayout=$(getCumulativePayout $peer)
  if [ $cumulativePayout == 0 ]
  then
    echo 0
    return
  fi

  cashedPayout=$(getLastCashedPayout $peer)
  let uncashedAmount=$cumulativePayout-$cashedPayout
  echo $uncashedAmount
}

function cashout() {
  local peer=$1
  local response=$(curl -s -XPOST "http://localhost:$DEBUG_API/chequebook/cashout/$peer")  
  local txHash=$(echo "$response" | jq -r .transactionHash)
  a=$(date "+%Y-%m-%d")
  if [ "$txHash" == "null" ]
  then
    echo could not cash out cheque for $peer: $(echo "$response" | jq -r .code,.message)
    return
  fi

  echo cashing out cheque for $peer in transaction $txHash >> /root/history/$a.history

  result="$(curl -s http://localhost:$DEBUG_API/chequebook/cashout/$peer | jq .result)"
  while [ "$result" == "null" ]
  do
    sleep 5
    result=$(curl -s $DEBUG_API/chequebook/cashout/$peer | jq .result)
  done
}

function cashoutAll() {
  local minAmount=$1
  for peer in $(getPeers)
  do
    local uncashedAmount=$(getUncashedAmount $peer)
    if (( "$uncashedAmount" > $minAmount ))
    then
      echo "uncashed cheque for $peer ($uncashedAmount uncashed)" >&2
      cashout $peer
    fi
  done
}

function listAllUncashed() {
  for peer in $(getPeers)
  do
    local uncashedAmount=$(getUncashedAmount $peer)
    if (( "$uncashedAmount" > 0 ))
    then
      echo $peer $uncashedAmount
    fi
  done
}

for((i=0;i<30;i++))
do
  n=$[1635+3*$i]
  m=$[1+$i]

  DEBUG_API=$n
  [ -z ${MIN_AMOUNT+x} ] && MIN_AMOUNT=1000000

  case $1 in
  cashout)
    echo bee_$m:$DEBUG_API:cashout
    cashout $2
    ;;
  cashout-all)
    echo bee_$m:$DEBUG_API:cashout-all
    cashoutAll $MIN_AMOUNT
    ;;
  list-uncashed|*)
    echo bee_$m:$DEBUG_API:list-uncashed
    listAllUncashed
    ;;
  esac

done
