cd /root/
./cashout.sh cashout-all 5

docker-compose stop
sleep 5

rm -rf /data/bee/.bee1/localstore/*
rm -rf /data/bee/.bee2/localstore/*
rm -rf /data/bee/.bee3/localstore/*
rm -rf /data/bee/.bee4/localstore/*
rm -rf /data/bee/.bee5/localstore/*
rm -rf /data/bee/.bee6/localstore/*
rm -rf /data/bee/.bee7/localstore/*
rm -rf /data/bee/.bee8/localstore/*
rm -rf /data/bee/.bee9/localstore/*
rm -rf /data/bee/.bee10/localstore/*
rm -rf /data/bee/.bee11/localstore/*
rm -rf /data/bee/.bee12/localstore/*
rm -rf /data/bee/.bee13/localstore/*
rm -rf /data/bee/.bee14/localstore/*
rm -rf /data/bee/.bee15/localstore/*
rm -rf /data/bee/.bee16/localstore/*
rm -rf /data/bee/.bee17/localstore/*
rm -rf /data/bee/.bee18/localstore/*
rm -rf /data/bee/.bee19/localstore/*
rm -rf /data/bee/.bee20/localstore/*
rm -rf /data/bee/.bee21/localstore/*
rm -rf /data/bee/.bee22/localstore/*
rm -rf /data/bee/.bee23/localstore/*
rm -rf /data/bee/.bee24/localstore/*
rm -rf /data/bee/.bee25/localstore/*
rm -rf /data/bee/.bee26/localstore/*
rm -rf /data/bee/.bee27/localstore/*
rm -rf /data/bee/.bee28/localstore/*
rm -rf /data/bee/.bee29/localstore/*
rm -rf /data/bee/.bee30/localstore/*

sleep 5
cd /root/
docker-compose start

