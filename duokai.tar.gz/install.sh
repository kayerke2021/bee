#tar -zxvf installet ff=unixtar
mkdir -p /data/bee-clef-data
for i in `seq 1 30`
do
        mkdir -p /data/beedata/.bee$i
		
done
chmod 777 -R /data/bee-clef-data
chmod 777 -R /data/beedata

#apt-get install jq -y
#apt-get install curl -y
#apt-get install docker.io -y 
#curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
#chmod +x /usr/local/bin/docker-compose
#ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

#echo "0 1 * * * cd /root/ && bash cashout.sh cashout-all 5"  >>/var/spool/cron/crontabs/root
#echo "13 7 * * * /root/clear.sh"  >>/var/spool/cron/crontabs/root
